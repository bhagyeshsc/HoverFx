(function(){ 'use strict';
  const modules = {
"entrypoints/popup/main.ts": function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const browser_1 = require("wxt/browser");
const settings_1 = require("../../src/shared/settings");
const $ = (selector) => {
    const element = document.querySelector(selector);
    if (!element)
        throw new Error(`Missing element: ${selector}`);
    return element;
};
async function main() {
    const enabled = $('#enabled');
    const powerLabel = $('.power-label');
    const target = $('#target');
    const targetCode = $('#target-code');
    const targetName = $('#target-name');
    const siteName = $('#site-name');
    const siteState = $('#site-state');
    const siteToggle = $('#site-toggle');
    const siteSource = $('#site-source');
    const form = $('#add-site');
    const domainInput = $('#domain-input');
    const formError = $('#form-error');
    const excludedList = $('#excluded-list');
    const excludedCount = $('#site-count');
    const emptyExclusions = $('#empty-exclusions');
    let settings = await (0, settings_1.loadSettings)();
    let currentDomain = null;
    try {
        const [tab] = await browser_1.browser.tabs.query({ active: true, currentWindow: true });
        if (tab?.url && /^https?:\/\//.test(tab.url))
            currentDomain = (0, settings_1.normalizeDomain)(new URL(tab.url).hostname);
    }
    catch { /* Pages such as browser settings have no accessible URL. */ }
    function addOptions(select) {
        for (const code of settings_1.POPULAR_CURRENCIES) {
            const option = document.createElement('option');
            option.value = code;
            const display = new Intl.DisplayNames(['en'], { type: 'currency' }).of(code);
            option.textContent = `${code} · ${display || code}`;
            select.add(option);
        }
    }
    addOptions(target);
    addOptions(siteSource);
    function render() {
        enabled.checked = settings.enabled;
        powerLabel.textContent = settings.enabled ? 'On' : 'Off';
        target.value = settings.targetCurrency;
        targetCode.textContent = settings.targetCurrency;
        targetName.textContent = new Intl.DisplayNames(['en'], { type: 'currency' }).of(settings.targetCurrency) || settings.targetCurrency;
        siteToggle.disabled = !currentDomain;
        siteSource.disabled = !currentDomain;
        siteName.textContent = currentDomain || 'Unavailable on this browser page';
        const excluded = currentDomain ? (0, settings_1.siteIsExcluded)(currentDomain, settings.excludedSites) : false;
        siteState.querySelector('.state-text').textContent = !settings.enabled ? 'Paused' : excluded ? 'Excluded' : currentDomain ? 'Active' : 'Unavailable';
        siteState.classList.toggle('off', !settings.enabled || excluded || !currentDomain);
        siteToggle.textContent = excluded ? 'Enable on this site' : 'Exclude this site';
        siteSource.value = currentDomain ? (0, settings_1.siteOverride)(currentDomain, settings.sourceOverrides) || '' : '';
        excludedCount.textContent = `${settings.excludedSites.length} excluded`;
        excludedList.replaceChildren();
        for (const site of settings.excludedSites) {
            const item = document.createElement('li');
            const text = document.createElement('span');
            text.textContent = site;
            const remove = document.createElement('button');
            remove.type = 'button';
            remove.textContent = 'Remove';
            remove.setAttribute('aria-label', `Remove exclusion for ${site}`);
            remove.addEventListener('click', () => {
                settings.excludedSites = settings.excludedSites.filter((domain) => domain !== site);
                void persist();
            });
            item.append(text, remove);
            excludedList.append(item);
        }
        emptyExclusions.hidden = settings.excludedSites.length !== 0;
    }
    async function persist() {
        render();
        try {
            await (0, settings_1.saveSettings)(settings);
        }
        catch {
            formError.textContent = 'Could not save settings. Please try again.';
        }
    }
    enabled.addEventListener('change', () => { settings.enabled = enabled.checked; void persist(); });
    target.addEventListener('change', () => { settings.targetCurrency = target.value; void persist(); });
    siteToggle.addEventListener('click', () => {
        if (!currentDomain)
            return;
        const isExcluded = (0, settings_1.siteIsExcluded)(currentDomain, settings.excludedSites);
        settings.excludedSites = isExcluded
            ? settings.excludedSites.filter((site) => !(currentDomain === site || currentDomain.endsWith(`.${site}`)))
            : [...new Set([...settings.excludedSites, currentDomain])];
        void persist();
    });
    siteSource.addEventListener('change', () => {
        if (!currentDomain)
            return;
        if (!siteSource.value)
            delete settings.sourceOverrides[currentDomain];
        else
            settings.sourceOverrides[currentDomain] = siteSource.value;
        void persist();
    });
    form.addEventListener('submit', (event) => {
        event.preventDefault();
        formError.textContent = '';
        const domain = (0, settings_1.normalizeDomain)(domainInput.value);
        if (!domain) {
            formError.textContent = 'Enter a valid domain, for example example.com';
            return;
        }
        if (!settings.excludedSites.includes(domain))
            settings.excludedSites.push(domain);
        domainInput.value = '';
        void persist();
    });
    render();
}
void main().catch((error) => {
    console.error('[HoverFX] Popup failed to initialize', error);
    document.body.textContent = 'Could not load HoverFX settings. Try reopening the popup.';
});

},
"src/shared/settings.ts": function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POPULAR_CURRENCIES = exports.DEFAULT_SETTINGS = exports.SETTINGS_KEY = void 0;
exports.isSupportedCurrency = isSupportedCurrency;
exports.normalizeDomain = normalizeDomain;
exports.domainMatches = domainMatches;
exports.siteIsExcluded = siteIsExcluded;
exports.siteOverride = siteOverride;
exports.sanitizeSettings = sanitizeSettings;
exports.loadSettings = loadSettings;
exports.saveSettings = saveSettings;
const browser_1 = require("wxt/browser");
exports.SETTINGS_KEY = 'hoverfx:settings';
exports.DEFAULT_SETTINGS = {
    enabled: true,
    targetCurrency: 'INR',
    excludedSites: [],
    sourceOverrides: {},
};
exports.POPULAR_CURRENCIES = [
    'INR', 'USD', 'EUR', 'GBP', 'JPY', 'CAD', 'AUD', 'NZD', 'SGD', 'CHF',
    'AED', 'SAR', 'CNY', 'HKD', 'KRW', 'THB', 'MYR', 'IDR', 'PHP', 'VND',
    'ZAR', 'BRL', 'MXN', 'SEK', 'NOK', 'DKK', 'PLN', 'CZK', 'HUF', 'TRY',
    'RUB', 'ILS', 'NGN', 'PKR', 'BDT', 'LKR', 'NPR', 'EGP', 'TWD', 'KWD',
    'QAR', 'BHD', 'OMR', 'CLP', 'COP', 'ARS', 'UAH', 'RON',
];
const currencyCodes = new Set(exports.POPULAR_CURRENCIES);
function isSupportedCurrency(code) {
    return typeof code === 'string' && currencyCodes.has(code.toUpperCase());
}
function normalizeDomain(input) {
    const raw = input.trim().toLowerCase();
    if (!raw)
        return null;
    try {
        const url = new URL(raw.includes('://') ? raw : `https://${raw}`);
        const host = url.hostname.replace(/^www\./, '').replace(/\.$/, '');
        if (!host.includes('.') || !/^[a-z0-9.-]+$/.test(host) || host.includes('..'))
            return null;
        return host;
    }
    catch {
        return null;
    }
}
function domainMatches(hostname, excluded) {
    const host = hostname.toLowerCase().replace(/^www\./, '');
    return host === excluded || host.endsWith(`.${excluded}`);
}
function siteIsExcluded(hostname, excludedSites) {
    return excludedSites.some((domain) => domainMatches(hostname, domain));
}
function siteOverride(hostname, overrides) {
    const matches = Object.entries(overrides)
        .filter(([domain, currency]) => domainMatches(hostname, domain) && isSupportedCurrency(currency))
        .sort(([a], [b]) => b.length - a.length);
    return matches[0]?.[1] ?? null;
}
function sanitizeSettings(input) {
    if (!input || typeof input !== 'object')
        return { ...exports.DEFAULT_SETTINGS };
    const v = input;
    const excludedSites = Array.isArray(v.excludedSites)
        ? Array.from(new Set(v.excludedSites.filter((x) => typeof x === 'string')
            .map((x) => normalizeDomain(x)).filter((x) => Boolean(x)))).slice(0, 200)
        : [];
    const sourceOverrides = {};
    if (v.sourceOverrides && typeof v.sourceOverrides === 'object' && !Array.isArray(v.sourceOverrides)) {
        for (const [domain, currency] of Object.entries(v.sourceOverrides)) {
            const normalized = normalizeDomain(domain);
            if (normalized && isSupportedCurrency(currency))
                sourceOverrides[normalized] = currency.toUpperCase();
        }
    }
    return {
        enabled: typeof v.enabled === 'boolean' ? v.enabled : true,
        targetCurrency: isSupportedCurrency(v.targetCurrency) ? v.targetCurrency.toUpperCase() : 'INR',
        excludedSites,
        sourceOverrides,
    };
}
async function loadSettings() {
    const value = await browser_1.browser.storage.local.get(exports.SETTINGS_KEY);
    return sanitizeSettings(value[exports.SETTINGS_KEY]);
}
async function saveSettings(settings) {
    await browser_1.browser.storage.local.set({ [exports.SETTINGS_KEY]: sanitizeSettings(settings) });
}

}
};
  const cache = Object.create(null);
  const browserApi = typeof browser !== 'undefined' ? browser : chrome;
  const imports = {
    defineBackground(definition){ return typeof definition === 'function' ? definition() : definition.main(); },
    defineContentScript(definition){ Promise.resolve().then(()=>definition.main()).catch(e=>console.error('[HoverFX] content error', e)); return definition; }
  };
  function load(id) {
    if(id==='wxt/browser') return {browser:browserApi};
    if(id==='#imports') return imports;
    if(cache[id]) return cache[id].exports;
    const loader=modules[id]; if(!loader) throw Error('Module missing: '+id);
    const mod={exports:{}};cache[id]=mod;
    loader(mod,mod.exports, name => {
      if (name==='wxt/browser'||name==='#imports')return load(name);
      const parts=id.split('/');parts.pop();
      for(const p of name.split('/')){if(p==='..')parts.pop();else if(p!=='.')parts.push(p)}
      return load(parts.join('/')+'.ts');
    });
    return mod.exports;
  }
  load("entrypoints/popup/main.ts");
})();