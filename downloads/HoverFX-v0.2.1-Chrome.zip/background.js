(function(){ 'use strict';
  const modules = {
"entrypoints/background.ts": function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const browser_1 = require("wxt/browser");
const _imports_1 = require("#imports");
const messages_1 = require("../src/shared/messages");
const RATES_KEY = 'hoverfx:rate-cache:v1';
const FRESH_FOR_MS = 6 * 60 * 60 * 1000;
const MAX_STALE_MS = 7 * 24 * 60 * 60 * 1000;
const MAX_ENTRIES = 120;
exports.default = (0, _imports_1.defineBackground)(() => {
    const inflight = new Map();
    const memoryCache = new Map();
    let writes = Promise.resolve();
    async function readCache() {
        const response = await browser_1.browser.storage.local.get(RATES_KEY);
        const value = response[RATES_KEY];
        return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
    }
    function storeEntry(pair, entry) {
        // Serialize updates: concurrent requests must not overwrite one another.
        writes = writes.then(async () => {
            const cache = await readCache();
            cache[pair] = entry;
            const ordered = Object.entries(cache)
                .filter(([, v]) => v && typeof v.fetchedAt === 'number')
                .sort(([, a], [, b]) => b.fetchedAt - a.fetchedAt)
                .slice(0, MAX_ENTRIES);
            await browser_1.browser.storage.local.set({ [RATES_KEY]: Object.fromEntries(ordered) });
        }).catch((error) => console.warn('[HoverFX] Could not persist rate cache', error));
    }
    async function fetchRate(from, to) {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 8500);
        try {
            const url = `https://api.frankfurter.dev/v2/rate/${encodeURIComponent(from.toLowerCase())}/${encodeURIComponent(to.toLowerCase())}`;
            const response = await fetch(url, { signal: controller.signal, cache: 'no-store' });
            if (!response.ok)
                throw new Error(`Rate service returned HTTP ${response.status}`);
            const data = await response.json();
            if (!data || typeof data !== 'object')
                throw new Error('Unexpected rate response');
            const { rate, date, base, quote } = data;
            if (typeof rate !== 'number' || !Number.isFinite(rate) || rate <= 0 ||
                typeof date !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(date) ||
                base !== from || quote !== to) {
                throw new Error('Rate response failed validation');
            }
            return { rate, date, fetchedAt: Date.now() };
        }
        finally {
            clearTimeout(timeout);
        }
    }
    async function getRate(from, to) {
        if (from === to)
            return {
                ok: true, rate: 1, date: new Date().toISOString().slice(0, 10), fetchedAt: Date.now(), stale: false,
            };
        const pair = `${from}:${to}`;
        const cache = await readCache();
        const saved = memoryCache.get(pair) ?? cache[pair];
        if (saved)
            memoryCache.set(pair, saved);
        const age = saved ? Date.now() - saved.fetchedAt : Infinity;
        if (saved && Number.isFinite(saved.rate) && saved.rate > 0 && age >= 0 && age < FRESH_FOR_MS) {
            return { ok: true, ...saved, stale: false };
        }
        try {
            const fetched = await fetchRate(from, to);
            memoryCache.set(pair, fetched);
            storeEntry(pair, fetched);
            return { ok: true, ...fetched, stale: false };
        }
        catch (error) {
            if (saved && Number.isFinite(saved.rate) && saved.rate > 0 && age >= 0 && age < MAX_STALE_MS) {
                return { ok: true, ...saved, stale: true };
            }
            return { ok: false, error: error instanceof Error ? error.message : 'Exchange rate unavailable' };
        }
    }
    browser_1.browser.runtime.onMessage.addListener((message, _sender, sendResponse) => {
        if (!(0, messages_1.isRateRequest)(message))
            return false;
        const pair = `${message.from}:${message.to}`;
        let task = inflight.get(pair);
        if (!task) {
            task = getRate(message.from, message.to).finally(() => inflight.delete(pair));
            inflight.set(pair, task);
        }
        void task.then(sendResponse).catch((error) => {
            sendResponse({ ok: false, error: String(error) });
        });
        // Keep the callback alive across asynchronous fetches in Chromium MV3.
        return true;
    });
});

},
"src/shared/messages.ts": function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isRateRequest = isRateRequest;
function isRateRequest(value) {
    if (!value || typeof value !== 'object')
        return false;
    const v = value;
    return v.type === 'HOVERFX_GET_RATE' &&
        typeof v.from === 'string' && /^[A-Z]{3}$/.test(v.from) &&
        typeof v.to === 'string' && /^[A-Z]{3}$/.test(v.to);
}

}
};
  const cache = Object.create(null);
  const browserApi = typeof browser !== 'undefined' ? browser : chrome;
  const imports = {
    defineBackground(definition){ return typeof definition === 'function' ? definition() : definition.main(); },
    defineContentScript(definition){ Promise.resolve().then(()=>definition.main()).catch(e=>console.error('[HoverFX] content error', e)); return definition; }
  };
  function load(id) {
    if(id==='wxt/browser') return {browser:browserApi};
    if(id==='#imports') return imports;
    if(cache[id]) return cache[id].exports;
    const loader=modules[id]; if(!loader) throw Error('Module missing: '+id);
    const mod={exports:{}};cache[id]=mod;
    loader(mod,mod.exports, name => {
      if (name==='wxt/browser'||name==='#imports')return load(name);
      const parts=id.split('/');parts.pop();
      for(const p of name.split('/')){if(p==='..')parts.pop();else if(p!=='.')parts.push(p)}
      return load(parts.join('/')+'.ts');
    });
    return mod.exports;
  }
  load("entrypoints/background.ts");
})();