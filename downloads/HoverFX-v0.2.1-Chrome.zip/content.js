(function(){ 'use strict';
  const modules = {
"entrypoints/content.ts": function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const browser_1 = require("wxt/browser");
const _imports_1 = require("#imports");
const dom_prices_1 = require("../src/content/dom-prices");
const currency_1 = require("../src/shared/currency");
const settings_1 = require("../src/shared/settings");
const HOVER_DELAY = 310;
const HIDE_DELAY = 240;
const TOOLTIP_STYLES = `
:host { all: initial; position: fixed; z-index: 2147483647; pointer-events: none;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Inter, system-ui, sans-serif; }
* { box-sizing: border-box; }
.panel { pointer-events: none; width: max-content; min-width: 128px;
  max-width: calc(100vw - 16px); padding: 10px 13px 11px;
  background: #fff; border: 1px solid #e0e6e1; border-radius: 9px;
  box-shadow: 0 8px 24px rgba(18,30,21,.12), 0 1px 3px rgba(18,30,21,.04);
  color: #202922; -webkit-font-smoothing: antialiased;
  animation: hoverfx-enter .13s ease-out; }
.pair { color: #647268; font-size: 11px; font-weight: 610; letter-spacing: .015em;
  line-height: 1.4; }
.amount { margin-top: 2px; font-size: 23px; font-weight: 670; letter-spacing: -.04em;
  line-height: 1.2; font-variant-numeric: tabular-nums; overflow-wrap: anywhere; }
.amount.error { color: #a63e36; font-size: 12px; font-weight: 590; letter-spacing: 0; }
@keyframes hoverfx-enter { from { opacity: 0; transform: translateY(3px); }
  to { opacity: 1; transform: translateY(0); } }
@media (prefers-reduced-motion: reduce) { .panel { animation: none; } }
`;
exports.default = (0, _imports_1.defineContentScript)({
    matches: ['<all_urls>'],
    runAt: 'document_idle',
    async main() {
        if (!document.documentElement)
            return;
        const hostname = location.hostname.toLowerCase();
        if (!hostname)
            return;
        let settings = await (0, settings_1.loadSettings)();
        const canRun = () => settings.enabled && !(0, settings_1.siteIsExcluded)(hostname, settings.excludedSites);
        let hoverTimer;
        let hideTimer;
        let hovered = null;
        let shownKey = '';
        let requestId = 0;
        let host = null;
        let panel = null;
        let amountEl = null;
        let pairEl = null;
        function cancelHover() {
            clearTimeout(hoverTimer);
            hoverTimer = undefined;
        }
        function cancelHide() {
            clearTimeout(hideTimer);
            hideTimer = undefined;
        }
        function hideImmediately() {
            cancelHover();
            cancelHide();
            requestId++;
            host?.remove();
            host = null;
            panel = null;
            amountEl = null;
            pairEl = null;
            hovered = null;
            shownKey = '';
        }
        function queueHide() {
            if (!host)
                return;
            cancelHide();
            hideTimer = setTimeout(hideImmediately, HIDE_DELAY);
        }
        function placeTooltip(hit) {
            if (!host || !panel)
                return;
            const { bounds } = hit;
            const width = panel.offsetWidth || 160;
            const height = panel.offsetHeight || 70;
            const left = Math.max(8, Math.min(window.innerWidth - width - 8, bounds.left));
            const below = bounds.bottom + 12;
            const top = below + height < window.innerHeight - 8
                ? below : Math.max(8, bounds.top - height - 12);
            host.style.left = `${left}px`;
            host.style.top = `${top}px`;
        }
        function tooltipNode(tag, className, content = '') {
            const element = document.createElement(tag);
            element.className = className;
            element.textContent = content;
            return element;
        }
        function buildTooltip(hit) {
            host?.remove();
            host = document.createElement('div');
            host.id = 'hoverfx-overlay-host';
            const shadow = host.attachShadow({ mode: 'closed' });
            const style = document.createElement('style');
            style.textContent = TOOLTIP_STYLES;
            shadow.append(style);
            panel = tooltipNode('div', 'panel');
            pairEl = tooltipNode('span', 'pair', `${hit.price.currency} → ${settings.targetCurrency}`);
            amountEl = tooltipNode('div', 'amount', '…');
            amountEl.setAttribute('role', 'status');
            amountEl.setAttribute('aria-live', 'polite');
            panel.append(pairEl, amountEl);
            shadow.append(panel);
            document.documentElement.append(host);
            placeTooltip(hit);
        }
        async function displayRate(hit, from) {
            const current = ++requestId;
            if (!amountEl || !pairEl)
                return;
            pairEl.textContent = `${from} → ${settings.targetCurrency}`;
            amountEl.textContent = '…';
            amountEl.classList.remove('error');
            if (from === settings.targetCurrency) {
                amountEl.textContent = (0, currency_1.formatConverted)(hit.price.amount, from);
                placeTooltip(hit);
                return;
            }
            try {
                const reply = await browser_1.browser.runtime.sendMessage({ type: 'HOVERFX_GET_RATE', from, to: settings.targetCurrency });
                if (current !== requestId || !amountEl)
                    return;
                if (!reply?.ok)
                    throw new Error(reply?.error || 'Rate unavailable');
                amountEl.textContent = (0, currency_1.formatConverted)(hit.price.amount * reply.rate, settings.targetCurrency);
                placeTooltip(hit);
            }
            catch {
                if (current !== requestId || !amountEl)
                    return;
                amountEl.textContent = 'Rate unavailable';
                amountEl.classList.add('error');
                placeTooltip(hit);
            }
        }
        function show(hit) {
            if (!canRun())
                return;
            hovered = hit;
            shownKey = `${hit.price.text}:${hit.bounds.left}:${hit.bounds.top}`;
            buildTooltip(hit);
            void displayRate(hit, hit.price.currency);
        }
        function pointerMove(event) {
            if (!canRun() || event.pointerType === 'touch')
                return;
            const ctx = {
                hostname,
                language: document.documentElement.lang || navigator.language,
                pageCurrency: (0, dom_prices_1.readPageCurrency)(),
                overrideCurrency: (0, settings_1.siteOverride)(hostname, settings.sourceOverrides),
            };
            const hit = (0, dom_prices_1.findPriceAtPoint)(event.clientX, event.clientY, ctx);
            if (!hit) {
                cancelHover();
                if (host)
                    queueHide();
                return;
            }
            cancelHide();
            const key = `${hit.price.text}:${hit.bounds.left}:${hit.bounds.top}`;
            if (host && key === shownKey)
                return;
            if (hovered && key === `${hovered.price.text}:${hovered.bounds.left}:${hovered.bounds.top}` && hoverTimer)
                return;
            cancelHover();
            if (host)
                hideImmediately();
            hovered = hit;
            hoverTimer = setTimeout(() => {
                hoverTimer = undefined;
                show(hit);
            }, HOVER_DELAY);
        }
        document.addEventListener('pointermove', pointerMove, { passive: true });
        document.addEventListener('pointerdown', hideImmediately, { passive: true });
        document.addEventListener('scroll', hideImmediately, { passive: true, capture: true });
        window.addEventListener('blur', hideImmediately);
        browser_1.browser.storage.onChanged.addListener((changes, area) => {
            if (area !== 'local' || !changes[settings_1.SETTINGS_KEY])
                return;
            const previous = settings;
            settings = (0, settings_1.sanitizeSettings)(changes[settings_1.SETTINGS_KEY].newValue);
            if (previous.enabled !== settings.enabled || previous.targetCurrency !== settings.targetCurrency ||
                (0, settings_1.siteIsExcluded)(hostname, previous.excludedSites) !== (0, settings_1.siteIsExcluded)(hostname, settings.excludedSites)) {
                hideImmediately();
            }
        });
    },
});

},
"src/content/dom-prices.ts": function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.findPriceAtPoint = findPriceAtPoint;
exports.readPageCurrency = readPageCurrency;
const currency_1 = require("../shared/currency");
const REJECTED_TAGS = 'script,style,textarea,input,select,option,button,code,pre,kbd,samp,svg,canvas,[contenteditable=""],[contenteditable="true"],[role="textbox"],[aria-hidden="true"]';
function isInExcludedElement(element) {
    return Boolean(element.closest(REJECTED_TAGS) || element.closest('#hoverfx-overlay-host'));
}
function scanContainer(element) {
    const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT, {
        acceptNode(node) {
            const parent = node.parentElement;
            return parent && !isInExcludedElement(parent) && node.textContent?.trim()
                ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
        },
    });
    const spans = [];
    let text = '';
    while (walker.nextNode()) {
        const node = walker.currentNode;
        const value = node.textContent ?? '';
        // Never collect a large page subsection or scan excessive descendants.
        if (spans.length >= 28 || text.length + value.length > 240)
            return null;
        spans.push({ node, start: text.length, end: text.length + value.length });
        text += value;
    }
    return spans.length ? { text, spans } : null;
}
function asRange(match, spans) {
    const first = spans.find((s) => s.end > match.start);
    const last = spans.find((s) => s.end >= match.end && s.start < match.end);
    if (!first || !last)
        return null;
    const range = document.createRange();
    range.setStart(first.node, match.start - first.start);
    range.setEnd(last.node, match.end - last.start);
    return range;
}
function near(pointX, pointY, rect) {
    return rect.width > 0 && rect.height > 0 && pointX >= rect.left - 3 && pointX <= rect.right + 3 &&
        pointY >= rect.top - 3 && pointY <= rect.bottom + 3;
}
function findPriceAtPoint(x, y, ctx) {
    const element = document.elementFromPoint(x, y);
    if (!element || isInExcludedElement(element))
        return null;
    let current = element;
    for (let depth = 0; depth < 5 && current; depth++, current = current.parentElement) {
        if (isInExcludedElement(current))
            return null;
        const scan = scanContainer(current);
        if (!scan)
            continue;
        const matches = (0, currency_1.extractPrices)(scan.text, ctx);
        for (const match of matches) {
            const range = asRange(match, scan.spans);
            if (!range)
                continue;
            try {
                const rectangles = Array.from(range.getClientRects());
                const hit = rectangles.find((rect) => near(x, y, rect));
                if (hit)
                    return { price: match, bounds: hit };
            }
            finally {
                range.detach();
            }
        }
    }
    return null;
}
function readPageCurrency() {
    const selectors = [
        'meta[property="product:price:currency"]',
        'meta[property="og:price:currency"]',
        'meta[itemprop="priceCurrency"]',
        'meta[name="currency"]',
    ];
    for (const selector of selectors) {
        const value = document.querySelector(selector)?.content?.toUpperCase().trim();
        if (value && /^[A-Z]{3}$/.test(value))
            return value;
    }
    return null;
}

},
"src/shared/currency.ts": function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolveCurrency = resolveCurrency;
exports.parsePriceNumber = parsePriceNumber;
exports.extractPrices = extractPrices;
exports.formatConverted = formatConverted;
const ISO = [
    'USD', 'EUR', 'GBP', 'INR', 'JPY', 'CAD', 'AUD', 'NZD', 'SGD', 'CHF',
    'AED', 'SAR', 'CNY', 'HKD', 'KRW', 'THB', 'MYR', 'IDR', 'PHP', 'VND',
    'ZAR', 'BRL', 'MXN', 'SEK', 'NOK', 'DKK', 'PLN', 'CZK', 'HUF', 'TRY',
    'RUB', 'ILS', 'NGN', 'PKR', 'BDT', 'LKR', 'NPR', 'EGP', 'TWD', 'KWD',
    'QAR', 'BHD', 'OMR', 'CLP', 'COP', 'ARS', 'UAH', 'RON',
];
const EXPLICIT_TOKENS = {
    'US$': 'USD', 'CA$': 'CAD', 'C$': 'CAD', 'AU$': 'AUD', 'A$': 'AUD',
    'NZ$': 'NZD', 'S$': 'SGD', 'SG$': 'SGD', 'HK$': 'HKD', 'R$': 'BRL',
    'MX$': 'MXN', 'NT$': 'TWD', '₹': 'INR', '€': 'EUR', '£': 'GBP',
    '₩': 'KRW', '₽': 'RUB', '₺': 'TRY', '₪': 'ILS', '₦': 'NGN',
    '₱': 'PHP', '฿': 'THB', '₫': 'VND', '₴': 'UAH', 'zł': 'PLN',
};
const AMBIGUOUS_TOKENS = ['$', '¥', '￥', 'Rs', 'Rs.', 'kr'];
const tokens = [...ISO, ...Object.keys(EXPLICIT_TOKENS), ...AMBIGUOUS_TOKENS]
    .sort((a, b) => b.length - a.length)
    .map((token) => token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
const TOKEN = `(?:${tokens.join('|')})`;
const DIGITS = String.raw `(?:\d{1,3}(?:[\s\u00a0\u202f,.'’]\d{3})+(?:[,.]\d{1,2})?|\d+(?:[,.]\d{1,2})?)`;
const PREFIX = new RegExp(`(^|[^\\p{L}\\p{N}])(${TOKEN})[ \\u00a0\\u202f]*(${DIGITS})(?=$|[^\\p{L}\\p{N}])`, 'gu');
const SUFFIX = new RegExp(`(^|[^\\p{L}\\p{N}])(${DIGITS})[ \\u00a0\\u202f]*(${TOKEN})(?=$|[^\\p{L}\\p{N}])`, 'gu');
const countryCurrencies = {
    us: 'USD', ca: 'CAD', au: 'AUD', nz: 'NZD', sg: 'SGD', hk: 'HKD',
    in: 'INR', jp: 'JPY', cn: 'CNY', br: 'BRL', mx: 'MXN', pk: 'PKR',
    lk: 'LKR', se: 'SEK', no: 'NOK', dk: 'DKK', ch: 'CHF', gb: 'GBP',
};
function contextCurrency(ctx) {
    if (ctx.overrideCurrency && ISO.includes(ctx.overrideCurrency))
        return ctx.overrideCurrency;
    if (ctx.pageCurrency && ISO.includes(ctx.pageCurrency.toUpperCase()))
        return ctx.pageCurrency.toUpperCase();
    const country = ctx.hostname.toLowerCase().split('.').at(-1) ?? '';
    if (countryCurrencies[country])
        return countryCurrencies[country];
    const localeCountry = ctx.language?.replace('_', '-').split('-')[1]?.toLowerCase();
    return (localeCountry && countryCurrencies[localeCountry]) || null;
}
function resolveCurrency(token, ctx) {
    if (ISO.includes(token))
        return { code: token, assumed: false };
    if (EXPLICIT_TOKENS[token])
        return { code: EXPLICIT_TOKENS[token], assumed: false };
    const hint = contextCurrency(ctx);
    if (token === '$') {
        const allowed = ['USD', 'CAD', 'AUD', 'NZD', 'SGD', 'HKD', 'MXN', 'TWD', 'ARS', 'CLP', 'COP'];
        if (hint && allowed.includes(hint))
            return { code: hint, assumed: true };
        return { code: 'USD', assumed: true };
    }
    if (token === '¥' || token === '￥')
        return { code: hint === 'CNY' ? 'CNY' : 'JPY', assumed: true };
    if (token === 'Rs' || token === 'Rs.') {
        return { code: hint && ['INR', 'PKR', 'LKR', 'NPR'].includes(hint) ? hint : 'INR', assumed: true };
    }
    if (token === 'kr') {
        return hint && ['SEK', 'NOK', 'DKK'].includes(hint) ? { code: hint, assumed: true } : null;
    }
    return null;
}
function parsePriceNumber(raw) {
    let n = raw.replace(/[\s\u00a0\u202f'’]/g, '');
    const comma = n.lastIndexOf(',');
    const dot = n.lastIndexOf('.');
    if (comma !== -1 && dot !== -1) {
        const decimal = comma > dot ? ',' : '.';
        const grouping = decimal === ',' ? '.' : ',';
        n = n.split(grouping).join('').replace(decimal, '.');
    }
    else if (comma !== -1 || dot !== -1) {
        const separator = comma !== -1 ? ',' : '.';
        const parts = n.split(separator);
        if (parts.length > 2 && parts.slice(1).every((part) => part.length === 3)) {
            n = parts.join('');
        }
        else if (parts.length === 2 && parts[1]?.length === 3 && parts[0].length <= 3) {
            n = parts.join('');
        }
        else if (parts.length === 2 && (parts[1]?.length ?? 0) <= 2) {
            n = parts.join('.');
        }
        else {
            return null;
        }
    }
    if (!/^\d+(?:\.\d+)?$/.test(n))
        return null;
    const value = Number(n);
    return Number.isFinite(value) && value <= 1e12 ? value : null;
}
function extractPrices(text, context) {
    if (!text || text.length > 800)
        return [];
    const result = [];
    for (const [regex, prefix] of [[PREFIX, true], [SUFFIX, false]]) {
        regex.lastIndex = 0;
        for (const match of text.matchAll(regex)) {
            const offset = match[1]?.length ?? 0;
            const token = prefix ? match[2] : match[3];
            const number = prefix ? match[3] : match[2];
            if (!token || !number)
                continue;
            const currency = resolveCurrency(token, context);
            const amount = parsePriceNumber(number);
            if (!currency || amount === null)
                continue;
            const start = (match.index ?? 0) + offset;
            const matchedText = match[0].slice(offset);
            result.push({
                start, end: start + matchedText.length, text: matchedText,
                amount, currency: currency.code, assumedCurrency: currency.assumed,
            });
        }
    }
    return result.sort((a, b) => a.start - b.start)
        .filter((match, index, matches) => !matches.slice(0, index).some((before) => before.start === match.start && before.end === match.end));
}
function formatConverted(value, currency) {
    return new Intl.NumberFormat(undefined, {
        style: 'currency', currency, currencyDisplay: 'symbol',
        maximumFractionDigits: value > 0 && value < 1 ? 4 : undefined,
    }).format(value);
}

},
"src/shared/settings.ts": function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POPULAR_CURRENCIES = exports.DEFAULT_SETTINGS = exports.SETTINGS_KEY = void 0;
exports.isSupportedCurrency = isSupportedCurrency;
exports.normalizeDomain = normalizeDomain;
exports.domainMatches = domainMatches;
exports.siteIsExcluded = siteIsExcluded;
exports.siteOverride = siteOverride;
exports.sanitizeSettings = sanitizeSettings;
exports.loadSettings = loadSettings;
exports.saveSettings = saveSettings;
const browser_1 = require("wxt/browser");
exports.SETTINGS_KEY = 'hoverfx:settings';
exports.DEFAULT_SETTINGS = {
    enabled: true,
    targetCurrency: 'INR',
    excludedSites: [],
    sourceOverrides: {},
};
exports.POPULAR_CURRENCIES = [
    'INR', 'USD', 'EUR', 'GBP', 'JPY', 'CAD', 'AUD', 'NZD', 'SGD', 'CHF',
    'AED', 'SAR', 'CNY', 'HKD', 'KRW', 'THB', 'MYR', 'IDR', 'PHP', 'VND',
    'ZAR', 'BRL', 'MXN', 'SEK', 'NOK', 'DKK', 'PLN', 'CZK', 'HUF', 'TRY',
    'RUB', 'ILS', 'NGN', 'PKR', 'BDT', 'LKR', 'NPR', 'EGP', 'TWD', 'KWD',
    'QAR', 'BHD', 'OMR', 'CLP', 'COP', 'ARS', 'UAH', 'RON',
];
const currencyCodes = new Set(exports.POPULAR_CURRENCIES);
function isSupportedCurrency(code) {
    return typeof code === 'string' && currencyCodes.has(code.toUpperCase());
}
function normalizeDomain(input) {
    const raw = input.trim().toLowerCase();
    if (!raw)
        return null;
    try {
        const url = new URL(raw.includes('://') ? raw : `https://${raw}`);
        const host = url.hostname.replace(/^www\./, '').replace(/\.$/, '');
        if (!host.includes('.') || !/^[a-z0-9.-]+$/.test(host) || host.includes('..'))
            return null;
        return host;
    }
    catch {
        return null;
    }
}
function domainMatches(hostname, excluded) {
    const host = hostname.toLowerCase().replace(/^www\./, '');
    return host === excluded || host.endsWith(`.${excluded}`);
}
function siteIsExcluded(hostname, excludedSites) {
    return excludedSites.some((domain) => domainMatches(hostname, domain));
}
function siteOverride(hostname, overrides) {
    const matches = Object.entries(overrides)
        .filter(([domain, currency]) => domainMatches(hostname, domain) && isSupportedCurrency(currency))
        .sort(([a], [b]) => b.length - a.length);
    return matches[0]?.[1] ?? null;
}
function sanitizeSettings(input) {
    if (!input || typeof input !== 'object')
        return { ...exports.DEFAULT_SETTINGS };
    const v = input;
    const excludedSites = Array.isArray(v.excludedSites)
        ? Array.from(new Set(v.excludedSites.filter((x) => typeof x === 'string')
            .map((x) => normalizeDomain(x)).filter((x) => Boolean(x)))).slice(0, 200)
        : [];
    const sourceOverrides = {};
    if (v.sourceOverrides && typeof v.sourceOverrides === 'object' && !Array.isArray(v.sourceOverrides)) {
        for (const [domain, currency] of Object.entries(v.sourceOverrides)) {
            const normalized = normalizeDomain(domain);
            if (normalized && isSupportedCurrency(currency))
                sourceOverrides[normalized] = currency.toUpperCase();
        }
    }
    return {
        enabled: typeof v.enabled === 'boolean' ? v.enabled : true,
        targetCurrency: isSupportedCurrency(v.targetCurrency) ? v.targetCurrency.toUpperCase() : 'INR',
        excludedSites,
        sourceOverrides,
    };
}
async function loadSettings() {
    const value = await browser_1.browser.storage.local.get(exports.SETTINGS_KEY);
    return sanitizeSettings(value[exports.SETTINGS_KEY]);
}
async function saveSettings(settings) {
    await browser_1.browser.storage.local.set({ [exports.SETTINGS_KEY]: sanitizeSettings(settings) });
}

},
"src/shared/messages.ts": function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isRateRequest = isRateRequest;
function isRateRequest(value) {
    if (!value || typeof value !== 'object')
        return false;
    const v = value;
    return v.type === 'HOVERFX_GET_RATE' &&
        typeof v.from === 'string' && /^[A-Z]{3}$/.test(v.from) &&
        typeof v.to === 'string' && /^[A-Z]{3}$/.test(v.to);
}

}
};
  const cache = Object.create(null);
  const browserApi = typeof browser !== 'undefined' ? browser : chrome;
  const imports = {
    defineBackground(definition){ return typeof definition === 'function' ? definition() : definition.main(); },
    defineContentScript(definition){ Promise.resolve().then(()=>definition.main()).catch(e=>console.error('[HoverFX] content error', e)); return definition; }
  };
  function load(id) {
    if(id==='wxt/browser') return {browser:browserApi};
    if(id==='#imports') return imports;
    if(cache[id]) return cache[id].exports;
    const loader=modules[id]; if(!loader) throw Error('Module missing: '+id);
    const mod={exports:{}};cache[id]=mod;
    loader(mod,mod.exports, name => {
      if (name==='wxt/browser'||name==='#imports')return load(name);
      const parts=id.split('/');parts.pop();
      for(const p of name.split('/')){if(p==='..')parts.pop();else if(p!=='.')parts.push(p)}
      return load(parts.join('/')+'.ts');
    });
    return mod.exports;
  }
  load("entrypoints/content.ts");
})();